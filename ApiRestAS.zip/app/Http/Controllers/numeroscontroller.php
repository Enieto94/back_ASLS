<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\numero;

class numeroscontroller extends Controller
{
    //
    public function getNumero()
    {
        return response()->json(numero::all(), 200);
    }

    public function getNumeroxid($id)
    {
        $numero = numero::find($id);
        if (is_null($numero)) {
            return response()->json(['Mensaje' => 'numero no encontrado'], 404);
        }

        return response()->json($numero::find($id), 200);
    }

    public function insertNumero(Request $request)
    {
        $numero = numero::create($request->all());
        return response($numero, 200);
    }

    public function updateNumero(Request $request, $id)
    {
        $numero = numero::find($id);
        if (is_null($numero)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $numero->update($request->all());
        return response($numero, 200);
    }

    public function deleteNumero($id)
    {
        $numero = numero::find($id);
        if (is_null($numero)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $numero->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
