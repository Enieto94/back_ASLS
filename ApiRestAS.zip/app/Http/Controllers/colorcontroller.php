<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\color;

class colorcontroller extends Controller
{
    //
    //
    public function getColor()
    {
        return response()->json(color::all(), 200);
    }

    public function getColorxid($id)
    {
        $color = color::find($id);
        if (is_null($color)) {
            return response()->json(['Mensaje' => 'color no encontrado'], 404);
        }

        return response()->json($color::find($id), 200);
    }

    public function insertColor(Request $request)
    {
        $color = color::create($request->all());
        return response($color, 200);
    }

    public function updateColor(Request $request, $id)
    {
        $color = color::find($id);
        if (is_null($color)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $color->update($request->all());
        return response($color, 200);
    }

    public function deleteColor($id)
    {
        $color = color::find($id);
        if (is_null($color)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $color->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
