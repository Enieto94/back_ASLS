<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\verbo;


class verbocontroller extends Controller
{
    //
    public function getVerbo()
    {
        return response()->json(verbo::all(), 200);
    }

    public function getVerboxid($id)
    {
        $verbo = verbo::find($id);
        if (is_null($verbo)) {
            return response()->json(['Mensaje' => 'tema no encontrado'], 404);
        }

        return response()->json($verbo::find($id), 200);
    }

    public function insertVerbo(Request $request)
    {
        $verbo = verbo::create($request->all());
        return response($verbo, 200);
    }

    public function updateVerbo(Request $request, $id)
    {
        $verbo = verbo::find($id);
        if (is_null($verbo)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $verbo->update($request->all());
        return response($verbo, 200);
    }

    public function deleteVerbo($id)
    {
        $verbo = verbo::find($id);
        if (is_null($verbo)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $verbo->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
