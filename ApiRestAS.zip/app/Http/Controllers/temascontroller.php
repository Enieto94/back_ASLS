<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tema;

class temascontroller extends Controller
{
    //
    public function getTema()
    {
        return response()->json(tema::all(), 200);
    }

    public function getTemaxid($id)
    {
        $tema = tema::find($id);
        if (is_null($tema)) {
            return response()->json(['Mensaje' => 'tema no encontrado'], 404);
        }

        return response()->json($tema::find($id), 200);
    }

    public function insertTema(Request $request)
    {
        $tema = tema::create($request->all());
        return response($tema, 200);
    }

    public function updateTema(Request $request, $id)
    {
        $tema = tema::find($id);
        if (is_null($tema)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $tema->update($request->all());
        return response($tema, 200);
    }

    public function deleteTema($id)
    {
        $tema = tema::find($id);
        if (is_null($tema)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $tema->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
