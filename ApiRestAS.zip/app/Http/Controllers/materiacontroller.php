<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\materia;

class materiacontroller extends Controller
{
    //
    public function getMateria()
    {
        return response()->json(materia::all(), 200);
    }

    public function getMateriaxid($id)
    {
        $materia = materia::find($id);
        if (is_null($materia)) {
            return response()->json(['Mensaje' => 'tema no encontrada'], 404);
        }

        return response()->json($materia::find($id), 200);
    }

    public function insertMateria(Request $request)
    {
        $materia = materia::create($request->all());
        return response($materia, 200);
    }

    public function updateMateria(Request $request, $id)
    {
        $materia = materia::find($id);
        if (is_null($materia)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $materia->update($request->all());
        return response($materia, 200);
    }

    public function deleteMateria($id)
    {
        $materia = materia::find($id);
        if (is_null($materia)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $materia->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
