<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pregunta;

class preguntacontroller extends Controller
{
    //
    public function getPregunta()
    {
        return response()->json(pregunta::all(), 200);
    }

    public function getPreguntaxid($id)
    {
        $pregunta = pregunta::find($id);
        if (is_null($pregunta)) {
            return response()->json(['Mensaje' => 'tema no encontrado'], 404);
        }

        return response()->json($pregunta::find($id), 200);
    }

    public function insertPregunta(Request $request)
    {
        $pregunta = pregunta::create($request->all());
        return response($pregunta, 200);
    }

    public function updatePregunta(Request $request, $id)
    {
        $pregunta = pregunta::find($id);
        if (is_null($pregunta)) {

            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $pregunta->update($request->all());
        return response($pregunta, 200);
    }

    public function deletePregunta($id)
    {
        $pregunta = pregunta::find($id);
        if (is_null($pregunta)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $pregunta->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
