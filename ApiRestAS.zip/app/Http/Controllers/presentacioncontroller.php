<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\presentacion;


class presentacioncontroller extends Controller
{
    //
    public function getPresentacion()
    {
        return response()->json(presentacion::all(), 200);
    }

    public function getPresentacionxid($id)
    {
        $presentacion = presentacion::find($id);
        if (is_null($presentacion)) {
            return response()->json(['Mensaje' => 'tema no encontrado'], 404);
        }
        return response()->json($presentacion::find($id), 200);
    }

    public function insertPresentacino(Request $request)
    {
        $presentacion = presentacion::create($request->all());
        return response($presentacion, 200);
    }

    public function updatePresentacion(Request $request, $id)
    {
        $presentacion = presentacion::find($id);
        if (is_null($presentacion)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $presentacion->update($request->all());
        return response($presentacion, 200);
    }

    public function deletePresentacion($id)
    {
        $presentacion = presentacion::find($id);
        if (is_null($presentacion)) {
            return response()->json(['Mensaje' => 'Registro no Encontrado'], 404);
        }
        $presentacion->delete();
        return response()->json(['Mensaje' => 'Registro eliminado'], 200);
    }
}
