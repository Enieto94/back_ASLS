<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class materia extends Model
{
    public $guarded = [];
    use HasFactory;
}
