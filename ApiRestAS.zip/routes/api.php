<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Crear ruta

Route::get('colores', 'App\Http\Controllers\colorcontroller@getColor');
Route::get('color/{id}', 'App\Http\Controllers\colorcontroller@getColorxid');
Route::post('addcolor', 'App\Http\Controllers\colorcontroller@insertColor');
Route::put('updatecolor/{id}', 'App\Http\Controllers\colorcontroller@updateColor');
Route::delete('delecolor/{id}', 'App\Http\Controllers\colorcontroller@deleteColor');

Route::get('temas', 'App\Http\Controllers\temascontroller@getTema');
Route::get('tema/{id}', 'App\Http\Controllers\temascontroller@getTemaxid');
Route::post('addtema', 'App\Http\Controllers\temascontroller@insertTema');
Route::put('updatetema/{id}', 'App\Http\Controllers\temascontroller@updateTema');
Route::delete('deletema/{id}', 'App\Http\Controllers\temascontroller@deleteTema');


Route::get('numeros', 'App\Http\Controllers\numerosController@getNumero');
Route::get('numero/{id}', 'App\Http\Controllers\numerosController@getNumeroxid');
Route::post('addnumero', 'App\Http\Controllers\numerosController@insertNumero');
Route::put('updatenumero/{id}', 'App\Http\Controllers\numerosController@updateNumero');
Route::delete('deletenumero/{id}', 'App\Http\Controllers\numerosController@deleteNumero');

Route::get('materia', 'App\Http\Controllers\materiacontroller@getMateria');
Route::get('materia/{id}', 'App\Http\Controllers\materiacontroller@getMateriaxid');
Route::post('addmateria', 'App\Http\Controllers\materiacontroller@insertMateria');
Route::put('updatemateria/{id}', 'App\Http\Controllers\materiacontroller@updateMateria');
Route::delete('deletemateria/{id}', 'App\Http\Controllers\materiacontroller@deleteMateria');

Route::get('color', 'App\Http\Controllers\colorcontroller@getColor');
Route::get('color/{id}', 'App\Http\Controllers\colorcontroller@getColorxid');
Route::post('addcolor', 'App\Http\Controllers\colorcontroller@insertColor');
Route::put('updatecolor/{id}', 'App\Http\Controllers\colorcontroller@updateColor');
Route::delete('deletecolor/{id}', 'App\Http\Controllers\colorcontroller@deleteColor');
